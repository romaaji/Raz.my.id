# Responsive Portfolio Website with HTML, CSS & JavaScript

![Responsive Portfolio Website with HTML, CSS and JavaScript](https://raw.githubusercontent.com/wpcodevo/LC25-portfolio-website/setup/responsive%20portfolio%20website%20with%20html%20css.jpg "Responsive Portfolio Website with HTML, CSS and JavaScript")

The Figma file of the Responsive Portfolio Website can be found on my [website](https://www.ziddah.com)
