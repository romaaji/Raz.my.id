# Free-Simple-Login-Template
Kali ini saya mencoba membuat Simple Login Template Menggunakan Bootstrap 4.
Gunakan template ini untuk belajar...
Mohon maaf jika ada kesalahan / apapun itu.karna saya juga masih belajar.
<br>
<a target="_blank" href="https://wafarifki.github.io/Free-Simple-Login-Template">Klik disini untuk melihat demo</a>
<br>

<b> ScreenShoot Versi Desktop </b>
<img src="https://github.com/wafarifki/Simple-Login-Template/blob/main/ScreenShoot/Desktop.png">

<br>
<b> ScreenShoot Versi Mobile </b>
<img src="https://github.com/wafarifki/Simple-Login-Template/blob/main/ScreenShoot/Mobile.png">




<b>#Mari Mengenal Saya Lebih Dekat :D </b>
<br><a href="https://instagram.com/wafarifki_" target="_blank">Instagram</a>
<br><a href="https://facebook.com/bekasiHACKERlive" target="_blank">Facebook</a>
<br><a href="https://wafarifki.tk" target="_blank">Situs Web</a>

